from setuptools import setup, find_packages

setup(
    name="Thanos_snap",
    version="0.1.0",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "thanos_snap=thanos_snap.main:main",
        ],
    },
    install_requires=[],  # Leave empty since no dependencies
    python_requires=">=3.6",  # Specify supported Python versions
    description="A tool to randomly eliminate half of the lines in a file.",
    author="Elias Backe",
    author_email="eliasbacke03@gmail.com",
    url="https://github.com/yourusername/yourproject",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
